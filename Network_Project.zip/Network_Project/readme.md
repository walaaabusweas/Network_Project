# Web-browser with PyQt5

A practicing project in The Shortcut's Python 0 to 1 programme Feb 2019

## Dependency
- [PyQt5](https://pypi.org/project/PyQt5/)

## How to run
`git clone https://github.com/dangquangdon/PyQt5-Web-browser.git`

`pip install -r requirements.txt`

`cd PyQt5-Web-browser`

`python main.py`
